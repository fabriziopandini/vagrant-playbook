# -*- coding: utf-8 -*-
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

#TODO: remove dependencies from ansible
from ansible.compat.six import string_types, text_type, integer_types

compat_string_types = string_types
compat_text_type = text_type
compat_integer_types = integer_types
